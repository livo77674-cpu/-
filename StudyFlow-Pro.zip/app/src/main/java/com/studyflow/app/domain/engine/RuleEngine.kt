// ПУТЬ: com/studyflow/app/domain/engine/RuleEngine.kt

package com.studyflow.app.domain.engine

import com.studyflow.app.data.local.StudyBlockEntity
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.domain.model.TimerPhase
import kotlin.math.roundToInt

/**
 * Результат проверки дневной перегрузки по эшелону TIER_1.
 */
data class Tier1OverloadResult(
    val isTier1Blocked: Boolean,
    val usedMinutes: Int,
    val limitMinutes: Int,
    val remainingMinutes: Int,
    val recommendedFallbackTiers: List<CognitiveTier>,
    val recommendation: String
)

/**
 * Решение движка правил в ответ на накопление отвлечений («Мысли блуждают»).
 */
data class DistractionDecision(
    val shouldTriggerEarlyClosure: Boolean,
    val shouldSwitchModality: Boolean,
    val recommendedNextPhase: TimerPhase?,
    val recommendedNextTier: CognitiveTier,
    val recommendation: String
)

/**
 * Тип рекомендуемого адаптивного действия при снижении энергии.
 */
enum class EnergyAdaptationAction {
    /** Энергия стабильна — можно продолжать текущий план. */
    CONTINUE_AS_PLANNED,

    /** Снизить когнитивный эшелон следующих блоков (например, TIER_1 -> TIER_2/TIER_3). */
    DOWNGRADE_NEXT_TASKS,

    /** Завершить учебный день или существенно сократить объём из-за истощения ресурса. */
    SHORTEN_DAY_OR_STOP
}

/**
 * Результат анализа динамики энергии после завершённых учебных блоков.
 */
data class EnergyDropEvaluation(
    val action: EnergyAdaptationAction,
    val isLowEnergyThresholdHit: Boolean,
    val hasConsecutiveEnergyDrop: Boolean,
    val latestEnergyAfter: Int?,
    val recommendation: String
)

/**
 * Результат контроля 5-го рабочего дня подряд (Deload-механика).
 */
data class DeloadEvaluation(
    val isDeloadRecommended: Boolean,
    val consecutiveWorkDays: Int,
    val allowedTiers: List<CognitiveTier>,
    val recommendation: String
)

/**
 * Движок адаптивных правил StudyFlow.
 *
 * Содержит исключительно чистые функции без зависимостей от Android SDK и состояния,
 * что гарантирует детерминированность и простоту модульного тестирования.
 */
object RuleEngine {

    const val BASE_TIER1_LIMIT_MINUTES: Int = 240
    const val POOR_SLEEP_THRESHOLD: Int = 2
    const val POOR_SLEEP_PENALTY_FACTOR: Double = 0.60 // сокращение на 40% -> 144 мин

    const val DISTRACTION_TRIGGER_THRESHOLD: Int = 2
    const val LOW_ENERGY_THRESHOLD: Int = 2
    const val CONSECUTIVE_DAYS_FOR_DELOAD: Int = 5

    const val MIN_WORK_DURATION_MINUTES: Int = 50
    const val MAX_WORK_DURATION_MINUTES: Int = 80
    const val CLOSURE_DURATION_SECONDS: Int = 180 // 3 минуты
    const val SHORT_BREAK_SECONDS: Int = 900      // 15 минут
    const val LONG_BREAK_SECONDS: Int = 1200      // 20 минут
    const val LONG_BREAK_WORK_THRESHOLD_MINUTES: Int = 65

    /**
     * 1. Расчёт динамического дневного лимита для [CognitiveTier.TIER_1].
     *
     * Научное обоснование: недосып резко снижает ёмкость префронтальной коры и
     * увеличивает стоимость переключения внимания.
     * - Базовый лимит: 240 минут.
     * - При [sleepQuality] <= 2 лимит автоматически сокращается на 40% (до 144 минут).
     * - При активном разгрузочном дне ([isDeloadDay] = true) лимит TIER_1 равен 0 минут.
     */
    fun calculateTier1DailyLimit(
        sleepQuality: Int,
        isDeloadDay: Boolean = false
    ): Int {
        if (isDeloadDay) return 0

        val normalizedSleep = sleepQuality.coerceIn(1, 5)
        return if (normalizedSleep <= POOR_SLEEP_THRESHOLD) {
            (BASE_TIER1_LIMIT_MINUTES * POOR_SLEEP_PENALTY_FACTOR).roundToInt()
        } else {
            BASE_TIER1_LIMIT_MINUTES
        }
    }

    /**
     * 2. Проверка дневной перегрузки по эшелону TIER_1.
     *
     * Если суммарное фактическое время TIER_1 достигло или превысило дневной лимит,
     * новые задачи TIER_1 блокируются с рекомендацией переключиться на TIER_2 или TIER_3.
     */
    fun checkTier1Overload(
        tier1ActualMinutesToday: Int,
        tier1LimitMinutes: Int
    ): Tier1OverloadResult {
        val safeUsed = tier1ActualMinutesToday.coerceAtLeast(0)
        val safeLimit = tier1LimitMinutes.coerceAtLeast(0)
        val remaining = (safeLimit - safeUsed).coerceAtLeast(0)
        val isBlocked = safeUsed >= safeLimit

        return if (isBlocked) {
            Tier1OverloadResult(
                isTier1Blocked = true,
                usedMinutes = safeUsed,
                limitMinutes = safeLimit,
                remainingMinutes = 0,
                recommendedFallbackTiers = listOf(CognitiveTier.TIER_2, CognitiveTier.TIER_3),
                recommendation = "Дневной лимит тяжёлой работы TIER_1 ($safeLimit мин) исчерпан. " +
                    "Новые задачи TIER_1 заблокированы — переведите оставшиеся блоки в TIER_2 (Active Recall) " +
                    "или TIER_3 (Worked Examples)."
            )
        } else {
            Tier1OverloadResult(
                isTier1Blocked = false,
                usedMinutes = safeUsed,
                limitMinutes = safeLimit,
                remainingMinutes = remaining,
                recommendedFallbackTiers = emptyList(),
                recommendation = "Доступно ещё $remaining мин работы в эшелоне TIER_1."
            )
        }
    }

    /**
     * 3. Реакция на отвлечения внутри активного рабочего блока.
     *
     * Если кнопка «Мысли блуждают» нажата >= 2 раз, система рекомендует досрочно
     * перейти в фазу [TimerPhase.CLOSURE] (3-минутный буфер закрытия) и сменить
     * модальность или когнитивный эшелон следующей задачи.
     */
    fun evaluateDistractions(
        distractionCount: Int,
        currentTier: CognitiveTier
    ): DistractionDecision {
        val safeCount = distractionCount.coerceAtLeast(0)
        val nextTier = downgradeTier(currentTier)

        return if (safeCount >= DISTRACTION_TRIGGER_THRESHOLD) {
            DistractionDecision(
                shouldTriggerEarlyClosure = true,
                shouldSwitchModality = true,
                recommendedNextPhase = TimerPhase.CLOSURE,
                recommendedNextTier = nextTier,
                recommendation = "Зафиксировано $safeCount отвлечения: концентрация снижена. " +
                    "Рекомендуется досрочно перейти в 3-минутный буфер закрытия (CLOSURE), " +
                    "зафиксировать точку остановки и после отдыха сменить модальность задачи " +
                    "(рекомендуемый эшелон: ${nextTier.displayName})."
            )
        } else {
            DistractionDecision(
                shouldTriggerEarlyClosure = false,
                shouldSwitchModality = false,
                recommendedNextPhase = null,
                recommendedNextTier = currentTier,
                recommendation = "Уровень фокуса в норме (отвлечений: $safeCount)."
            )
        }
    }

    /**
     * 4. Реакция на падение субъективной энергии после учебных блоков.
     *
     * Условия срабатывания:
     * - Последний показатель `energyAfter <= 2`, ИЛИ
     * - Падение энергии 2 блока подряд:
     *   a) либо внутри 2 последних завершённых блоков подряд энергия падала (`energyAfter < energyBefore`),
     *   b) либо `energyAfter` последовательно снижался 2 перехода подряд (`e[n-2] > e[n-1] > e[n]`).
     */
    fun evaluateEnergyTrend(
        blocksTodayInOrder: List<StudyBlockEntity>
    ): EnergyDropEvaluation {
        val checkedInBlocks = blocksTodayInOrder.filter { it.energyAfter != null }
        if (checkedInBlocks.isEmpty()) {
            return EnergyDropEvaluation(
                action = EnergyAdaptationAction.CONTINUE_AS_PLANNED,
                isLowEnergyThresholdHit = false,
                hasConsecutiveEnergyDrop = false,
                latestEnergyAfter = null,
                recommendation = "Завершённых блоков с оценкой энергии пока нет."
            )
        }

        val latestEnergy = checkedInBlocks.last().energyAfter!!
        val isLowEnergy = latestEnergy <= LOW_ENERGY_THRESHOLD

        // Проверка А: снижение энергии внутри 2 последних блоков подряд (energyAfter < energyBefore)
        val twoConsecutiveIntraBlockDrops = if (checkedInBlocks.size >= 2) {
            val lastTwo = checkedInBlocks.takeLast(2)
            lastTwo.all { block ->
                val before = block.energyBefore
                val after = block.energyAfter
                before != null && after != null && after < before
            }
        } else {
            false
        }

        // Проверка Б: монотонное падение итоговой энергии (energyAfter) на 2 шагах подряд
        val twoConsecutiveAcrossBlockDrops = if (checkedInBlocks.size >= 3) {
            val lastThreeEnergies = checkedInBlocks.takeLast(3).map { it.energyAfter!! }
            lastThreeEnergies[0] > lastThreeEnergies[1] && lastThreeEnergies[1] > lastThreeEnergies[2]
        } else {
            false
        }

        val hasConsecutiveDrop = twoConsecutiveIntraBlockDrops || twoConsecutiveAcrossBlockDrops

        return when {
            isLowEnergy && hasConsecutiveDrop -> EnergyDropEvaluation(
                action = EnergyAdaptationAction.SHORTEN_DAY_OR_STOP,
                isLowEnergyThresholdHit = true,
                hasConsecutiveEnergyDrop = true,
                latestEnergyAfter = latestEnergy,
                recommendation = "Энергия упала до критического уровня ($latestEnergy/5) " +
                    "на фоне 2 блоков снижения подряд. Рекомендуется завершить учебный день " +
                    "для сохранения качества консолидации памяти."
            )

            isLowEnergy -> EnergyDropEvaluation(
                action = EnergyAdaptationAction.SHORTEN_DAY_OR_STOP,
                isLowEnergyThresholdHit = true,
                hasConsecutiveEnergyDrop = false,
                latestEnergyAfter = latestEnergy,
                recommendation = "Низкий уровень энергии после блока ($latestEnergy/5). " +
                    "Рекомендуется сократить учебный день или перевести оставшиеся задачи в TIER_3."
            )

            hasConsecutiveDrop -> EnergyDropEvaluation(
                action = EnergyAdaptationAction.DOWNGRADE_NEXT_TASKS,
                isLowEnergyThresholdHit = false,
                hasConsecutiveEnergyDrop = true,
                latestEnergyAfter = latestEnergy,
                recommendation = "Зафиксировано падение энергии 2 блока подряд (текущий уровень: $latestEnergy/5). " +
                    "Рекомендуется понизить когнитивный эшелон следующих задач до TIER_2/TIER_3 " +
                    "или сократить оставшийся план."
            )

            else -> EnergyDropEvaluation(
                action = EnergyAdaptationAction.CONTINUE_AS_PLANNED,
                isLowEnergyThresholdHit = false,
                hasConsecutiveEnergyDrop = false,
                latestEnergyAfter = latestEnergy,
                recommendation = "Динамика энергии стабильна ($latestEnergy/5). Можно продолжать по плану."
            )
        }
    }

    /**
     * 5. Контроль 5-го рабочего дня подряд (профилактика накопленного утомления / Deload).
     *
     * Если [consecutiveWorkDays] >= 5, система рекомендует разгрузочный день:
     * полный отказ от задач [CognitiveTier.TIER_1], допуск только TIER_2 и TIER_3.
     */
    fun evaluateDeloadNeed(consecutiveWorkDays: Int): DeloadEvaluation {
        val safeDays = consecutiveWorkDays.coerceAtLeast(0)
        return if (safeDays >= CONSECUTIVE_DAYS_FOR_DELOAD) {
            DeloadEvaluation(
                isDeloadRecommended = true,
                consecutiveWorkDays = safeDays,
                allowedTiers = listOf(CognitiveTier.TIER_2, CognitiveTier.TIER_3),
                recommendation = "Вы работаете $safeDays дн. подряд без разгрузки. " +
                    "Активирована рекомендация разгрузочного дня (Deload): " +
                    "исключите задачи TIER_1 и ограничьтесь лёгким повторением (TIER_2/TIER_3) или отдыхом."
            )
        } else {
            DeloadEvaluation(
                isDeloadRecommended = false,
                consecutiveWorkDays = safeDays,
                allowedTiers = CognitiveTier.entries,
                recommendation = "Серия рабочих дней: $safeDays из $CONSECUTIVE_DAYS_FOR_DELOAD до плановой разгрузки."
            )
        }
    }

    /**
     * Ограничивает длительность рабочей сессии научно обоснованным окном 50–80 минут.
     */
    fun clampWorkDurationMinutes(plannedMinutes: Int): Int =
        plannedMinutes.coerceIn(MIN_WORK_DURATION_MINUTES, MAX_WORK_DURATION_MINUTES)

    /**
     * Определяет длительность обязательного перерыва (фаза BREAK):
     * - Блок < 65 минут -> 15 минут (900 сек).
     * - Блок >= 65 минут -> 20 минут (1200 сек).
     */
    fun calculateRecommendedBreakSeconds(plannedWorkMinutes: Int): Int {
        return if (plannedWorkMinutes >= LONG_BREAK_WORK_THRESHOLD_MINUTES) {
            LONG_BREAK_SECONDS
        } else {
            SHORT_BREAK_SECONDS
        }
    }

    /**
     * Понижает когнитивный эшелон на один шаг (TIER_1 -> TIER_2 -> TIER_3).
     */
    fun downgradeTier(currentTier: CognitiveTier): CognitiveTier = when (currentTier) {
        CognitiveTier.TIER_1 -> CognitiveTier.TIER_2
        CognitiveTier.TIER_2 -> CognitiveTier.TIER_3
        CognitiveTier.TIER_3 -> CognitiveTier.TIER_3
    }
}
