// ПУТЬ: com/studyflow/app/ui/screens/ActiveTimerScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyflow.app.domain.model.TimerPhase
import com.studyflow.app.service.TimerSnapshot
import com.studyflow.app.ui.theme.CloseGlyph
import com.studyflow.app.ui.theme.LiquidGlassSurface
import com.studyflow.app.ui.theme.MetallicSurface
import com.studyflow.app.ui.theme.PauseGlyph
import com.studyflow.app.ui.theme.PlayGlyph
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.accentColor
import com.studyflow.app.ui.theme.cleanLabel
import com.studyflow.app.ui.theme.performTapHaptic
import com.studyflow.app.ui.theme.zincMetallicCanvas
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ActiveTimerScreen(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit
) {
    AnimatedContent(
        targetState = snapshot.phase,
        transitionSpec = {
            fadeIn(animationSpec = tween(250)) togetherWith fadeOut(animationSpec = tween(250))
        },
        label = "timer_phase_transition"
    ) { phase ->
        when (phase) {
            TimerPhase.WORK -> WorkPhaseContent(
                snapshot = snapshot,
                onPause = onPause,
                onResume = onResume,
                onRegisterDistraction = onRegisterDistraction,
                onTriggerEarlyClosure = onTriggerEarlyClosure,
                onStop = onStop
            )

            TimerPhase.CLOSURE -> ClosurePhaseContent(
                snapshot = snapshot,
                initialClosureNote = initialClosureNote,
                onSaveClosureNote = onSaveClosureNote
            )

            TimerPhase.BREAK -> BreakPhaseContent(
                snapshot = snapshot
            )

            TimerPhase.POST_CHECKIN -> PostCheckInPhaseContent(
                snapshot = snapshot,
                onSubmitPostCheckIn = onSubmitPostCheckIn,
                onStop = onStop
            )

            TimerPhase.IDLE -> Unit
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkPhaseContent(
    snapshot: TimerSnapshot,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit
) {
    val view = LocalView.current
    var showStopSheet by rememberSaveable { mutableStateOf(false) }

    // Медленное дыхание радиального серебряного ореола за центральной линзой
    val infiniteTransition = rememberInfiniteTransition(label = "work_halo")
    val haloScale by infiniteTransition.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4600, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_scale"
    )
    val haloAlpha by infiniteTransition.animateFloat(
        initialValue = 0.50f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4600, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .zincMetallicCanvas(
                topColor = StudyFlowColors.WorkCanvasTop,
                midColor = Color(0xFFF5F5F7),
                bottomColor = StudyFlowColors.WorkCanvasBottom
            )
    ) {
        // Статический/дышащий оптический ореол за линзой (без Modifier.blur)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val baseRadius = size.minDimension * 0.48f
            val r = baseRadius * if (snapshot.isRunning) haloScale else 0.92f
            val a = if (snapshot.isRunning) haloAlpha else 0.45f
            val center = Offset(size.width * 0.5f, size.height * 0.46f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = a),
                        Color(0xFFD4D4D8).copy(alpha = a * 0.25f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = r
                ),
                radius = r,
                center = center
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Верх: название, уровень нагрузки и Liquid Glass пилюля «Отвлёкся · N»
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = snapshot.activeBlockTitle.ifBlank { "Фокус" },
                        style = MaterialTheme.typography.titleLarge,
                        color = StudyFlowColors.InkPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(snapshot.activeBlockTier.accentColor())
                        )
                        Text(
                            text = snapshot.activeBlockTier.cleanLabel(),
                            style = MaterialTheme.typography.labelMedium,
                            color = StudyFlowColors.InkMuted
                        )
                    }
                }

                LiquidGlassSurface(
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.clickable {
                        view.performTapHaptic()
                        onRegisterDistraction()
                    }
                ) {
                    Text(
                        text = "Отвлёкся · ${snapshot.distractionCount}",
                        style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.InkPrimary,
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp)
                    )
                }
            }

            // Центр: 264.dp круглая Liquid Glass линза с 1.75.dp дугой прогресса
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Box(
                    modifier = Modifier.size(272.dp),
                    contentAlignment = Alignment.Center
                ) {
                    LiquidGlassSurface(
                        shape = CircleShape,
                        isCircularLens = true,
                        modifier = Modifier.size(264.dp)
                    ) {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = formatTimerMmSs(snapshot.remainingSeconds),
                                style = MaterialTheme.typography.displayLarge.copy(
                                    fontSize = 56.sp,
                                    lineHeight = 62.sp,
                                    fontWeight = FontWeight.Light,
                                    letterSpacing = (-2.2).sp,
                                    fontFeatureSettings = "tnum"
                                ),
                                color = StudyFlowColors.InkPrimary
                            )
                            Text(
                                text = if (snapshot.isRunning) "ФОКУС" else "ПАУЗА",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    letterSpacing = 1.4.sp
                                ),
                                color = StudyFlowColors.InkMuted
                            )
                        }
                    }

                    // Тонкая 1.75.dp дуга прогресса
                    Canvas(modifier = Modifier.size(268.dp)) {
                        val strokePx = 1.75.dp.toPx()
                        val inset = strokePx / 2f
                        val arcSize = Size(size.width - strokePx, size.height - strokePx)
                        val topLeft = Offset(inset, inset)

                        drawArc(
                            color = StudyFlowColors.Hairline,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokePx, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = StudyFlowColors.InkPrimary,
                            startAngle = -90f,
                            sweepAngle = 360f * snapshot.progressFraction.coerceIn(0f, 1f),
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokePx, cap = StrokeCap.Round)
                        )
                    }
                }

                // Подсказка раннего перехода к точке остановки при >= 2 отвлечениях
                AnimatedVisibility(
                    visible = snapshot.earlyClosureRecommended,
                    enter = fadeIn() + slideInVertically { it / 3 },
                    exit = fadeOut() + slideOutVertically { it / 3 }
                ) {
                    LiquidGlassSurface(
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.clickable {
                            view.performTapHaptic()
                            onTriggerEarlyClosure()
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(StudyFlowColors.WarningBar)
                            )
                            Text(
                                text = "Фокус падает · Закрыть мысль сейчас?",
                                style = MaterialTheme.typography.labelMedium,
                                color = StudyFlowColors.InkPrimary
                            )
                        }
                    }
                }
            }

            // Низ: графитовая «Пауза / Продолжить» и Liquid Glass «Завершить»
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        view.performTapHaptic()
                        if (snapshot.isRunning) onPause() else onResume()
                    },
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudyFlowColors.InkPrimary,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                ) {
                    if (snapshot.isRunning) {
                        PauseGlyph(color = Color.White, size = 13.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Пауза",
                            style = MaterialTheme.typography.labelLarge
                        )
                    } else {
                        PlayGlyph(color = Color.White, size = 13.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Продолжить",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                LiquidGlassSurface(
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clickable {
                            view.performTapHaptic()
                            showStopSheet = true
                        }
                ) {
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CloseGlyph(color = StudyFlowColors.InkPrimary, size = 12.dp)
                        Text(
                            text = "Завершить",
                            style = MaterialTheme.typography.labelLarge,
                            color = StudyFlowColors.InkPrimary
                        )
                    }
                }
            }
        }
    }

    // Подтверждение досрочной остановки через ModalBottomSheet (без AlertDialog)
    if (showStopSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showStopSheet = false },
            sheetState = sheetState,
            containerColor = StudyFlowColors.CanvasTop,
            contentColor = StudyFlowColors.InkPrimary,
            scrimColor = StudyFlowColors.InkPrimary.copy(alpha = 0.24f),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            dragHandle = { TimerSheetHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Завершить блок сейчас?",
                        style = MaterialTheme.typography.headlineSmall,
                        color = StudyFlowColors.InkPrimary
                    )
                    Text(
                        text = "Отработанные минуты сохранятся, но точка остановки и отдых будут пропущены",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.InkSecondary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .border(0.75.dp, StudyFlowColors.Hairline, RoundedCornerShape(10.dp))
                            .clickable {
                                view.performTapHaptic()
                                showStopSheet = false
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Отмена",
                            style = MaterialTheme.typography.labelLarge,
                            color = StudyFlowColors.InkPrimary
                        )
                    }

                    Button(
                        onClick = {
                            view.performTapHaptic()
                            showStopSheet = false
                            onStop()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudyFlowColors.CriticalBar,
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                    ) {
                        Text(
                            text = "Завершить",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ClosurePhaseContent(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit
) {
    val blockId = snapshot.activeBlockId
    var noteText by rememberSaveable(blockId) { mutableStateOf(initialClosureNote) }
    var lastSavedNote by remember(blockId) { mutableStateOf(initialClosureNote) }
    val latestNote by rememberUpdatedState(noteText)
    val latestSaveCallback by rememberUpdatedState(onSaveClosureNote)

    // Точное сохранение логики автосохранения (450L debounce)
    LaunchedEffect(blockId, noteText) {
        if (blockId != null && noteText != lastSavedNote) {
            delay(450L)
            latestSaveCallback(blockId, noteText)
            lastSavedNote = noteText
        }
    }

    // Гарантированный flush при уходе с экрана / автопереходе в перерыв
    DisposableEffect(blockId) {
        onDispose {
            if (blockId != null && latestNote.isNotBlank()) {
                latestSaveCallback(blockId, latestNote)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .zincMetallicCanvas()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = formatTimerMmSs(snapshot.remainingSeconds),
                style = MaterialTheme.typography.displayMedium.copy(
                    fontSize = 36.sp,
                    lineHeight = 42.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-1.6).sp,
                    fontFeatureSettings = "tnum"
                ),
                color = StudyFlowColors.InkPrimary
            )
            Text(
                text = "Точка остановки",
                style = MaterialTheme.typography.labelMedium,
                color = StudyFlowColors.InkSecondary
            )
        }

        MetallicSurface(
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(176.dp)
                ) {
                    if (noteText.isEmpty()) {
                        Text(
                            text = "На чём остановился и какой первый шаг завтра?",
                            style = MaterialTheme.typography.bodyLarge,
                            color = StudyFlowColors.InkSubtle
                        )
                    }
                    BasicTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        modifier = Modifier.fillMaxSize(),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = StudyFlowColors.InkPrimary
                        ),
                        cursorBrush = SolidColor(StudyFlowColors.InkPrimary)
                    )
                }

                HorizontalDivider(
                    thickness = 0.5.dp,
                    color = StudyFlowColors.Hairline
                )

                val statusText = when {
                    noteText.isBlank() -> "Автосохранение"
                    noteText == lastSavedNote -> "Сохранено"
                    else -> "Сохранение..."
                }
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (noteText.isNotBlank() && noteText == lastSavedNote) {
                        StudyFlowColors.LoadLight
                    } else {
                        StudyFlowColors.InkMuted
                    }
                )
            }
        }
    }
}

@Composable
private fun BreakPhaseContent(
    snapshot: TimerSnapshot
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .zincMetallicCanvas(
                topColor = StudyFlowColors.BreakCanvasTop,
                midColor = Color(0xFFECF1EF),
                bottomColor = StudyFlowColors.BreakCanvasBottom
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "ОТДЫХ БЕЗ ЭКРАНА",
            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.4.sp),
            color = StudyFlowColors.InkMuted
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = formatTimerMmSs(snapshot.remainingSeconds),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 52.sp,
                    lineHeight = 58.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-2.2).sp,
                    fontFeatureSettings = "tnum"
                ),
                color = StudyFlowColors.InkPrimary
            )

            Box(
                modifier = Modifier
                    .width(164.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(StudyFlowColors.TrackMuted)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(snapshot.progressFraction.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(999.dp))
                        .background(StudyFlowColors.LoadLight)
                )
            }
        }

        // Одна контентная карточка MetallicSurface с рекомендацией — без кнопки пропуска
        MetallicSurface(
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(StudyFlowColors.LoadLight)
                    )
                    Text(
                        text = "Восстановление",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudyFlowColors.InkMuted
                    )
                }
                Text(
                    text = snapshot.breakRecommendation
                        ?: "Посмотрите вдаль через окно, пройдитесь и выпейте стакан воды.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = StudyFlowColors.InkPrimary
                )
            }
        }
    }
}

@Composable
private fun PostCheckInPhaseContent(
    snapshot: TimerSnapshot,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit,
    onStop: () -> Unit
) {
    val view = LocalView.current
    var selectedEnergy by rememberSaveable { mutableIntStateOf(0) }
    val segments = listOf(
        1 to "Ноль",
        2 to "Мало",
        3 to "Норма",
        4 to "Бодро",
        5 to "Пик"
    )
    val actualMinutes = (snapshot.elapsedWorkSeconds / 60.0).roundToInt()
        .coerceAtLeast(if (snapshot.elapsedWorkSeconds > 0) 1 else 0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .zincMetallicCanvas()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Силы после блока",
                style = MaterialTheme.typography.headlineMedium,
                color = StudyFlowColors.InkPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "${snapshot.activeBlockTitle.ifBlank { "Блок" }} · $actualMinutes мин",
                style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                color = StudyFlowColors.InkSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            segments.forEach { (level, label) ->
                val isSelected = selectedEnergy == level
                val bgBrush = if (isSelected) {
                    Brush.verticalGradient(
                        listOf(StudyFlowColors.InkPrimary, StudyFlowColors.InkPrimary)
                    )
                } else {
                    Brush.verticalGradient(
                        listOf(StudyFlowColors.SurfaceTop, StudyFlowColors.SurfaceBottom)
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(72.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(brush = bgBrush)
                        .border(
                            width = 0.75.dp,
                            color = if (isSelected) {
                                StudyFlowColors.InkPrimary
                            } else {
                                StudyFlowColors.Hairline
                            },
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            view.performTapHaptic()
                            selectedEnergy = level
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = level.toString(),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Light,
                            fontFeatureSettings = "tnum"
                        ),
                        color = if (isSelected) Color.White else StudyFlowColors.InkPrimary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = if (isSelected) {
                            Color.White.copy(alpha = 0.85f)
                        } else {
                            StudyFlowColors.InkMuted
                        },
                        maxLines = 1
                    )
                }
            }
        }

        Button(
            onClick = {
                view.performTapHaptic()
                val blockId = snapshot.activeBlockId
                if (blockId != null && selectedEnergy in 1..5) {
                    onSubmitPostCheckIn(blockId, selectedEnergy)
                } else {
                    onStop()
                }
            },
            enabled = selectedEnergy in 1..5,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudyFlowColors.InkPrimary,
                contentColor = Color.White,
                disabledContainerColor = StudyFlowColors.TrackMuted,
                disabledContentColor = StudyFlowColors.InkSubtle
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
        ) {
            Text(
                text = "Готово",
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

@Composable
private fun TimerSheetHandle() {
    Box(
        modifier = Modifier
            .padding(top = 10.dp, bottom = 6.dp)
            .width(32.dp)
            .height(3.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(StudyFlowColors.ControlRingBorder)
    )
}

private fun formatTimerMmSs(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    val minutes = safe / 60
    val seconds = safe % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
