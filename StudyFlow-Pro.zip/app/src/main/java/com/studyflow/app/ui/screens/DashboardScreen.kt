// ПУТЬ: com/studyflow/app/ui/screens/DashboardScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyflow.app.data.local.DailyStateEntity
import com.studyflow.app.data.local.StudyBlockEntity
import com.studyflow.app.domain.engine.EnergyAdaptationAction
import com.studyflow.app.domain.engine.RuleEngine
import com.studyflow.app.domain.model.BlockStatus
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.ui.theme.CheckGlyph
import com.studyflow.app.ui.theme.LiquidGlassSurface
import com.studyflow.app.ui.theme.LockGlyph
import com.studyflow.app.ui.theme.MetallicSurface
import com.studyflow.app.ui.theme.MoonGlyph
import com.studyflow.app.ui.theme.PlayGlyph
import com.studyflow.app.ui.theme.PlusGlyph
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.TrashGlyph
import com.studyflow.app.ui.theme.accentColor
import com.studyflow.app.ui.theme.cleanLabel
import com.studyflow.app.ui.theme.performTapHaptic
import com.studyflow.app.ui.theme.zincMetallicCanvas
import com.studyflow.app.ui.viewmodel.StudyUiState
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.util.Locale
import kotlin.math.roundToInt

private enum class DashboardSegment(val label: String) {
    TIMER("Таймер"),
    SUMMARY("Сводка")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    uiState: StudyUiState,
    onSaveMorningSleep: (Int) -> Unit,
    onAddBlock: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit,
    onDeleteBlock: (StudyBlockEntity) -> Unit,
    onStartBlock: (block: StudyBlockEntity, energyBefore: Int) -> Unit,
    onApplyEnergyAdaptation: (List<StudyBlockEntity>) -> Unit,
    onDismissSnackbar: () -> Unit
) {
    val view = LocalView.current

    var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }
    var showSleepSheet by rememberSaveable { mutableStateOf(false) }
    var showAddSheet by rememberSaveable { mutableStateOf(false) }
    var blockPendingStart by remember { mutableStateOf<StudyBlockEntity?>(null) }

    val activeTab = DashboardSegment.entries[selectedTabIndex.coerceIn(0, 1)]

    // Автоскрытие плавающей стеклянной плашки уведомления
    val sanitizedToast = remember(uiState.snackbarMessage) {
        uiState.snackbarMessage?.takeIf { it.isNotBlank() }?.let(::sanitizeSystemMessage)
    }
    LaunchedEffect(sanitizedToast) {
        if (sanitizedToast != null) {
            delay(3200L)
            onDismissSnackbar()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .zincMetallicCanvas()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = if (activeTab == DashboardSegment.TIMER) 116.dp else 44.dp
            ),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Верхняя панель: дата + пилюля серии слева, Liquid Glass сна справа
            item(key = "top_bar") {
                DashboardTopBar(
                    dateIso = uiState.todayDate,
                    dailyState = uiState.dailyState,
                    onSleepClick = {
                        view.performTapHaptic()
                        showSleepSheet = true
                    }
                )
            }

            // 2. Центральный фокус: честное время «0 ч 00 м» и тонкая полоса запаса сложного
            item(key = "hero_focus") {
                HeroDailyFocus(
                    totalMinutesToday = uiState.totalMinutesToday,
                    hardUsedMinutes = uiState.tier1Overload.usedMinutes,
                    hardLimitMinutes = uiState.tier1Overload.limitMinutes
                )
            }

            // 3. Liquid Glass переключатель «Таймер / Сводка»
            item(key = "segmented_control") {
                LiquidGlassSegmentedControl(
                    selected = activeTab,
                    onSelect = { segment ->
                        if (segment != activeTab) {
                            view.performTapHaptic()
                            selectedTabIndex = segment.ordinal
                        }
                    }
                )
            }

            // 4. Содержимое активной вкладки
            when (activeTab) {
                DashboardSegment.TIMER -> {
                    val guidance = buildRuleGuidance(uiState)
                    val hasPlanned = uiState.blocks.any { it.status == BlockStatus.PLANNED }

                    if (guidance != null) {
                        item(key = "rule_banner") {
                            RuleGuidanceBanner(
                                text = guidance.text,
                                accentColor = guidance.accent,
                                showEaseAction = hasPlanned,
                                onEaseClick = {
                                    view.performTapHaptic()
                                    onApplyEnergyAdaptation(uiState.blocks)
                                }
                            )
                        }
                    }

                    if (uiState.blocks.isEmpty()) {
                        // Без белой коробки: тихая строка прямо на матовом холсте
                        item(key = "empty_state") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 36.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "На сегодня блоков нет · Нажмите «+ Новый блок»",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StudyFlowColors.InkMuted,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        item(key = "task_sheet") {
                            LinearTaskSheet(
                                blocks = uiState.blocks,
                                onStartClick = { block ->
                                    view.performTapHaptic()
                                    blockPendingStart = block
                                },
                                onDeleteClick = { block ->
                                    view.performTapHaptic()
                                    onDeleteBlock(block)
                                }
                            )
                        }
                    }
                }

                DashboardSegment.SUMMARY -> {
                    item(key = "engineering_summary") {
                        EngineeringSummaryContent(uiState = uiState)
                    }
                }
            }
        }

        // Компактный центрированный Liquid Glass док (без полноширинной двойной рамки)
        if (activeTab == DashboardSegment.TIMER) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp)
            ) {
                LiquidGlassSurface(
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Box(modifier = Modifier.padding(5.dp)) {
                        Button(
                            onClick = {
                                view.performTapHaptic()
                                showAddSheet = true
                            },
                            modifier = Modifier.height(42.dp),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StudyFlowColors.InkPrimary,
                                contentColor = Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(
                                defaultElevation = 0.dp,
                                pressedElevation = 0.dp
                            )
                        ) {
                            PlusGlyph(color = Color.White, size = 13.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Новый блок",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        // Плавающая стеклянная пилюля уведомления вместо тяжёлого Material Snackbar
        AnimatedVisibility(
            visible = sanitizedToast != null,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 82.dp)
        ) {
            sanitizedToast?.let { message ->
                LiquidGlassSurface(
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.clickable { onDismissSnackbar() }
                ) {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.labelMedium,
                        color = StudyFlowColors.InkPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }

    // Bottom Sheet: оценка сна (1–5)
    if (showSleepSheet) {
        SleepBottomSheet(
            initialQuality = uiState.dailyState?.sleepQuality ?: 4,
            onDismiss = { showSleepSheet = false },
            onSave = { quality ->
                showSleepSheet = false
                onSaveMorningSleep(quality)
            }
        )
    }

    // Bottom Sheet: однотаповый выбор уровня сил (1–5) перед запуском
    blockPendingStart?.let { targetBlock ->
        PreStartEnergyBottomSheet(
            block = targetBlock,
            onDismiss = { blockPendingStart = null },
            onSelectAndStart = { energy ->
                blockPendingStart = null
                onStartBlock(targetBlock, energy)
            }
        )
    }

    // Bottom Sheet: создание нового учебного блока
    if (showAddSheet) {
        NewBlockBottomSheet(
            isHardBlocked = uiState.tier1Overload.isTier1Blocked ||
                uiState.deloadEvaluation.isDeloadRecommended,
            onDismiss = { showAddSheet = false },
            onCreate = { title, tier, minutes ->
                showAddSheet = false
                onAddBlock(title, tier, minutes)
            }
        )
    }
}

@Composable
private fun DashboardTopBar(
    dateIso: String,
    dailyState: DailyStateEntity?,
    onSleepClick: () -> Unit
) {
    val dateLabel = remember(dateIso) { formatCompactRussianDate(dateIso) }
    val streakDay = dailyState?.consecutiveWorkDays?.coerceAtLeast(1) ?: 1

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = dateLabel,
                style = MaterialTheme.typography.titleMedium,
                color = StudyFlowColors.InkPrimary
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(StudyFlowColors.SurfaceTop.copy(alpha = 0.72f))
                    .border(
                        width = 0.75.dp,
                        color = StudyFlowColors.Hairline,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 7.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "День $streakDay",
                    style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.InkSecondary
                )
            }
        }

        // Интерактивная Liquid Glass пилюля оценки сна
        LiquidGlassSurface(
            shape = RoundedCornerShape(50),
            modifier = Modifier.clickable(onClick = onSleepClick)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MoonGlyph(
                    color = StudyFlowColors.InkSecondary,
                    size = 12.dp
                )
                val dotColor = when {
                    dailyState == null -> StudyFlowColors.LoadPractice
                    dailyState.sleepQuality <= RuleEngine.POOR_SLEEP_THRESHOLD -> StudyFlowColors.LoadPractice
                    else -> StudyFlowColors.LoadLight
                }
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(dotColor)
                )
                Text(
                    text = if (dailyState != null) {
                        "Сон ${dailyState.sleepQuality}/5"
                    } else {
                        "Оценить сон"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.InkPrimary
                )
            }
        }
    }
}

@Composable
private fun HeroDailyFocus(
    totalMinutesToday: Int,
    hardUsedMinutes: Int,
    hardLimitMinutes: Int
) {
    val totalText = remember(totalMinutesToday) { formatHoursMinutes(totalMinutesToday) }
    val fraction = when {
        hardLimitMinutes <= 0 -> 1f
        else -> (hardUsedMinutes.toFloat() / hardLimitMinutes.toFloat()).coerceIn(0f, 1f)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = totalText,
            style = MaterialTheme.typography.displayLarge.copy(
                fontSize = 50.sp,
                lineHeight = 56.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = (-2.0).sp,
                fontFeatureSettings = "tnum"
            ),
            color = StudyFlowColors.InkPrimary,
            maxLines = 1
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Запас сложного · $hardUsedMinutes / $hardLimitMinutes мин",
                style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                color = StudyFlowColors.InkSecondary
            )

            // Тонкая 2.dp волосяная полоска прогресса без окружающей карточки
            Box(
                modifier = Modifier
                    .width(190.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(StudyFlowColors.TrackMuted)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction)
                        .clip(RoundedCornerShape(999.dp))
                        .background(StudyFlowColors.InkPrimary)
                )
            }
        }
    }
}

@Composable
private fun LiquidGlassSegmentedControl(
    selected: DashboardSegment,
    onSelect: (DashboardSegment) -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(StudyFlowColors.TrackMuted.copy(alpha = 0.75f))
            .border(
                width = 0.5.dp,
                color = StudyFlowColors.ControlRingBorder.copy(alpha = 0.7f),
                shape = RoundedCornerShape(10.dp)
            )
            .padding(2.5.dp)
    ) {
        val segmentWidth = maxWidth / 2
        val targetOffset = if (selected == DashboardSegment.TIMER) 0.dp else segmentWidth
        val pillOffset by animateDpAsState(
            targetValue = targetOffset,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "segment_pill"
        )

        LiquidGlassSurface(
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .offset(x = pillOffset)
                .width(segmentWidth)
                .fillMaxHeight()
        ) {}

        Row(modifier = Modifier.fillMaxSize()) {
            DashboardSegment.entries.forEach { segment ->
                val isSelected = segment == selected
                val interactionSource = remember { MutableInteractionSource() }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            onClick = { onSelect(segment) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = segment.label,
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                        fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal,
                        color = if (isSelected) {
                            StudyFlowColors.InkPrimary
                        } else {
                            StudyFlowColors.InkSecondary
                        }
                    )
                }
            }
        }
    }
}

private data class RuleGuidance(
    val text: String,
    val accent: Color
)

private fun buildRuleGuidance(uiState: StudyUiState): RuleGuidance? = when {
    uiState.energyDropEvaluation.action == EnergyAdaptationAction.SHORTEN_DAY_OR_STOP ->
        RuleGuidance(
            text = "Низкий уровень сил · Лучше завершить день раньше ради качества памяти",
            accent = StudyFlowColors.CriticalBar
        )

    uiState.energyDropEvaluation.action == EnergyAdaptationAction.DOWNGRADE_NEXT_TASKS ->
        RuleGuidance(
            text = "Силы падают 2 блока подряд · Облегчить оставшиеся задачи?",
            accent = StudyFlowColors.WarningBar
        )

    uiState.deloadEvaluation.isDeloadRecommended ->
        RuleGuidance(
            text = "5-й день без разгрузки · Сегодня лучше ограничиться практикой и лёгким обзором",
            accent = StudyFlowColors.WarningBar
        )

    uiState.tier1Overload.isTier1Blocked ->
        RuleGuidance(
            text = "Дневной запас сложного исчерпан · Новые задачи переводим в практику",
            accent = StudyFlowColors.WarningBar
        )

    else -> null
}

@Composable
private fun RuleGuidanceBanner(
    text: String,
    accentColor: Color,
    showEaseAction: Boolean,
    onEaseClick: () -> Unit
) {
    MetallicSurface(
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 10.dp, top = 11.dp, bottom = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(24.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(accentColor)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.InkPrimary,
                modifier = Modifier.weight(1f)
            )
            if (showEaseAction) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(StudyFlowColors.CanvasMid)
                        .border(0.75.dp, StudyFlowColors.Hairline, RoundedCornerShape(8.dp))
                        .clickable(onClick = onEaseClick)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Облегчить",
                        style = MaterialTheme.typography.labelMedium,
                        color = StudyFlowColors.InkPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun LinearTaskSheet(
    blocks: List<StudyBlockEntity>,
    onStartClick: (StudyBlockEntity) -> Unit,
    onDeleteClick: (StudyBlockEntity) -> Unit
) {
    MetallicSurface(
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            blocks.forEachIndexed { index, block ->
                LinearTaskRow(
                    block = block,
                    onClick = {
                        if (block.status != BlockStatus.COMPLETED) {
                            onStartClick(block)
                        }
                    },
                    onDeleteClick = { onDeleteClick(block) }
                )
                if (index < blocks.lastIndex) {
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 58.dp, end = 14.dp),
                        thickness = 0.5.dp,
                        color = StudyFlowColors.Hairline
                    )
                }
            }
        }
    }
}

@Composable
private fun LinearTaskRow(
    block: StudyBlockEntity,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val tier = block.toCognitiveTier()
    val isCompleted = block.status == BlockStatus.COMPLETED

    val subtitle = buildList {
        add(tier.cleanLabel())
        if (block.status == BlockStatus.DOWNGRADED) {
            add("Облегчён")
        }
        if (block.energyBefore != null && block.energyAfter != null) {
            add("Силы ${block.energyBefore} → ${block.energyAfter}")
        }
    }.joinToString(" · ")

    val durationText = if (isCompleted) {
        "Факт · ${block.actualMinutes.coerceAtLeast(1)} мин"
    } else {
        "${block.plannedMinutes} мин"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isCompleted, onClick = onClick)
            .padding(start = 14.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Тактильное круглое кольцо 32.dp с PlayGlyph / CheckGlyph и 5.dp точкой сложности
        Box(modifier = Modifier.size(34.dp)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(StudyFlowColors.SurfaceTop)
                    .border(
                        width = 1.dp,
                        color = StudyFlowColors.ControlRingBorder,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isCompleted) {
                    CheckGlyph(
                        color = StudyFlowColors.InkMuted,
                        size = 13.dp
                    )
                } else {
                    PlayGlyph(
                        color = StudyFlowColors.InkPrimary,
                        size = 12.dp
                    )
                }
            }

            // 5.dp микро-точка сложности
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(Color.White)
                    .padding(1.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCompleted) tier.accentColor().copy(alpha = 0.4f) else tier.accentColor()
                    )
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = block.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (isCompleted) StudyFlowColors.InkMuted else StudyFlowColors.InkPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                color = StudyFlowColors.InkMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Text(
            text = durationText,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontFeatureSettings = "tnum"
            ),
            color = if (isCompleted) StudyFlowColors.InkMuted else StudyFlowColors.InkPrimary
        )

        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onDeleteClick),
            contentAlignment = Alignment.Center
        ) {
            TrashGlyph(
                color = StudyFlowColors.InkSubtle,
                size = 14.dp
            )
        }
    }
}

@Composable
private fun EngineeringSummaryContent(
    uiState: StudyUiState
) {
    val hardMin = uiState.minutesForTier(CognitiveTier.TIER_1)
    val practiceMin = uiState.minutesForTier(CognitiveTier.TIER_2)
    val lightMin = uiState.minutesForTier(CognitiveTier.TIER_3)
    val hardLimit = uiState.tier1Overload.limitMinutes
    val completedCount = uiState.blocks.count { it.status == BlockStatus.COMPLETED }

    val energyBlocks = remember(uiState.blocks) {
        uiState.blocks.filter { it.energyAfter != null }
    }
    val checkpoints = remember(uiState.blocks) {
        uiState.blocks.filter { it.closureNote.isNotBlank() }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Верхняя двухколоночная метрика (gap 8.dp)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetallicSurface(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SectionLabel("Отработано")
                    Text(
                        text = formatHoursMinutes(uiState.totalMinutesToday),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontSize = 24.sp,
                            lineHeight = 28.sp,
                            fontWeight = FontWeight.Light,
                            fontFeatureSettings = "tnum"
                        ),
                        color = StudyFlowColors.InkPrimary,
                        maxLines = 1
                    )
                    Text(
                        text = "$completedCount / ${uiState.blocks.size} блоков",
                        style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.InkMuted
                    )
                }
            }

            MetallicSurface(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SectionLabel("Остаток сложного")
                    Text(
                        text = "${uiState.tier1Overload.remainingMinutes} м",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontSize = 24.sp,
                            lineHeight = 28.sp,
                            fontWeight = FontWeight.Light,
                            fontFeatureSettings = "tnum"
                        ),
                        color = StudyFlowColors.InkPrimary,
                        maxLines = 1
                    )
                    Text(
                        text = "из $hardLimit м",
                        style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.InkMuted
                    )
                }
            }
        }

        // Распределение
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SectionLabel("Распределение", modifier = Modifier.padding(start = 2.dp))

            val maxRef = maxOf(hardLimit, hardMin, practiceMin, lightMin, 60).toFloat()
            MetallicSurface(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    DistributionRow(
                        label = CognitiveTier.TIER_1.cleanLabel(),
                        valueText = "$hardMin / $hardLimit мин",
                        progress = if (hardLimit > 0) {
                            (hardMin / hardLimit.toFloat()).coerceIn(0f, 1f)
                        } else {
                            1f
                        },
                        accent = CognitiveTier.TIER_1.accentColor()
                    )
                    HorizontalDivider(thickness = 0.5.dp, color = StudyFlowColors.Hairline)
                    DistributionRow(
                        label = CognitiveTier.TIER_2.cleanLabel(),
                        valueText = "$practiceMin мин",
                        progress = (practiceMin / maxRef).coerceIn(0f, 1f),
                        accent = CognitiveTier.TIER_2.accentColor()
                    )
                    HorizontalDivider(thickness = 0.5.dp, color = StudyFlowColors.Hairline)
                    DistributionRow(
                        label = CognitiveTier.TIER_3.cleanLabel(),
                        valueText = "$lightMin мин",
                        progress = (lightMin / maxRef).coerceIn(0f, 1f),
                        accent = CognitiveTier.TIER_3.accentColor()
                    )
                }
            }
        }

        // Динамика сил
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionLabel("Динамика сил")
                energyBlocks.lastOrNull()?.energyAfter?.let { latest ->
                    Text(
                        text = "$latest / 5",
                        style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.InkSecondary
                    )
                }
            }

            MetallicSurface(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (energyBlocks.isEmpty()) {
                    Text(
                        text = "Появится после завершения первого блока",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.InkMuted,
                        modifier = Modifier.padding(14.dp)
                    )
                } else {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        EnergyDeltaCanvas(
                            blocks = energyBlocks,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(78.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Светлые точки · до старта",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudyFlowColors.InkSubtle
                            )
                            Text(
                                text = "Графит · после блока",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudyFlowColors.InkMuted
                            )
                        }
                    }
                }
            }
        }

        // Точки остановки
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SectionLabel("Точки остановки", modifier = Modifier.padding(start = 2.dp))

            MetallicSurface(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (checkpoints.isEmpty()) {
                    Text(
                        text = "Заметок на завтра пока нет",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.InkMuted,
                        modifier = Modifier.padding(14.dp)
                    )
                } else {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        checkpoints.forEachIndexed { index, block ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(5.dp)
                                            .clip(CircleShape)
                                            .background(block.toCognitiveTier().accentColor())
                                    )
                                    Text(
                                        text = block.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = StudyFlowColors.InkPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = block.closureNote,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StudyFlowColors.InkSecondary,
                                    modifier = Modifier.padding(start = 12.dp)
                                )
                            }
                            if (index < checkpoints.lastIndex) {
                                HorizontalDivider(
                                    thickness = 0.5.dp,
                                    color = StudyFlowColors.Hairline
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(
    text: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall.copy(
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.2.sp
        ),
        color = StudyFlowColors.InkMuted,
        modifier = modifier
    )
}

@Composable
private fun DistributionRow(
    label: String,
    valueText: String,
    progress: Float,
    accent: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.InkPrimary
                )
            }
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                color = StudyFlowColors.InkSecondary
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(StudyFlowColors.TrackMuted)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progress)
                    .clip(RoundedCornerShape(999.dp))
                    .background(accent)
            )
        }
    }
}

@Composable
private fun EnergyDeltaCanvas(
    blocks: List<StudyBlockEntity>,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val padX = 8.dp.toPx()
        val padY = 8.dp.toPx()
        val w = (size.width - padX * 2).coerceAtLeast(1f)
        val h = (size.height - padY * 2).coerceAtLeast(1f)

        // Волосяные направляющие (1, 3, 5)
        listOf(0f, 0.5f, 1f).forEach { ratio ->
            val y = padY + h * ratio
            drawLine(
                color = StudyFlowColors.Hairline,
                start = Offset(padX, y),
                end = Offset(size.width - padX, y),
                strokeWidth = 0.5.dp.toPx()
            )
        }

        fun yFor(level: Int): Float {
            val norm = (5 - level.coerceIn(1, 5)) / 4f
            return padY + h * norm
        }

        val afterPoints = blocks.mapIndexed { idx, b ->
            val x = if (blocks.size == 1) {
                padX + w * 0.5f
            } else {
                padX + w * (idx.toFloat() / (blocks.size - 1).toFloat())
            }
            Offset(x, yFor(b.energyAfter ?: 3))
        }

        // Вертикальные связки energyBefore -> energyAfter
        blocks.forEachIndexed { idx, block ->
            val before = block.energyBefore
            if (before != null) {
                val afterPt = afterPoints[idx]
                val beforePt = Offset(afterPt.x, yFor(before))
                drawLine(
                    color = StudyFlowColors.ControlRingBorder,
                    start = beforePt,
                    end = afterPt,
                    strokeWidth = 1.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.dp.toPx(),
                    center = beforePt
                )
                drawCircle(
                    color = StudyFlowColors.InkSubtle,
                    radius = 3.dp.toPx(),
                    center = beforePt,
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }

        // Линия тренда energyAfter
        if (afterPoints.size >= 2) {
            val path = Path().apply {
                moveTo(afterPoints.first().x, afterPoints.first().y)
                for (i in 1 until afterPoints.size) {
                    val prev = afterPoints[i - 1]
                    val curr = afterPoints[i]
                    val midX = (prev.x + curr.x) / 2f
                    cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                }
            }
            drawPath(
                path = path,
                color = StudyFlowColors.InkPrimary,
                style = Stroke(
                    width = 1.5.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }

        afterPoints.forEach { pt ->
            drawCircle(color = Color.White, radius = 4.dp.toPx(), center = pt)
            drawCircle(color = StudyFlowColors.InkPrimary, radius = 2.6.dp.toPx(), center = pt)
        }
    }
}

@Composable
private fun CompactSheetDragHandle() {
    Box(
        modifier = Modifier
            .padding(top = 10.dp, bottom = 6.dp)
            .width(32.dp)
            .height(3.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(StudyFlowColors.ControlRingBorder)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SleepBottomSheet(
    initialQuality: Int,
    onDismiss: () -> Unit,
    onSave: (Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val view = LocalView.current
    var selected by rememberSaveable { mutableIntStateOf(initialQuality.coerceIn(1, 5)) }
    val capacityMinutes = RuleEngine.calculateTier1DailyLimit(sleepQuality = selected)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = StudyFlowColors.CanvasTop,
        contentColor = StudyFlowColors.InkPrimary,
        scrimColor = StudyFlowColors.InkPrimary.copy(alpha = 0.24f),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        dragHandle = { CompactSheetDragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = "Качество сна",
                    style = MaterialTheme.typography.headlineSmall,
                    color = StudyFlowColors.InkPrimary
                )
                Text(
                    text = "Запас сложного сегодня · $capacityMinutes мин",
                    style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.InkSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..5).forEach { score ->
                    ScoreTile(
                        score = score,
                        selected = selected == score,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            view.performTapHaptic()
                            selected = score
                        }
                    )
                }
            }

            Button(
                onClick = {
                    view.performTapHaptic()
                    onSave(selected)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.InkPrimary,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                Text(
                    text = "Сохранить",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PreStartEnergyBottomSheet(
    block: StudyBlockEntity,
    onDismiss: () -> Unit,
    onSelectAndStart: (Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val view = LocalView.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = StudyFlowColors.CanvasTop,
        contentColor = StudyFlowColors.InkPrimary,
        scrimColor = StudyFlowColors.InkPrimary.copy(alpha = 0.24f),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        dragHandle = { CompactSheetDragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = "Уровень сил перед стартом",
                    style = MaterialTheme.typography.headlineSmall,
                    color = StudyFlowColors.InkPrimary
                )
                Text(
                    text = "${block.title} · ${block.plannedMinutes} мин",
                    style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                    color = StudyFlowColors.InkSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..5).forEach { score ->
                    ScoreTile(
                        score = score,
                        selected = false,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            view.performTapHaptic()
                            onSelectAndStart(score)
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "1 · Ноль",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudyFlowColors.InkMuted
                )
                Text(
                    text = "5 · Пик",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudyFlowColors.InkMuted
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewBlockBottomSheet(
    isHardBlocked: Boolean,
    onDismiss: () -> Unit,
    onCreate: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val view = LocalView.current

    var title by rememberSaveable { mutableStateOf("") }
    var selectedTier by remember {
        mutableStateOf(if (isHardBlocked) CognitiveTier.TIER_2 else CognitiveTier.TIER_1)
    }
    var durationSlider by rememberSaveable { mutableFloatStateOf(50f) }

    val plannedMinutes = durationSlider.roundToInt().coerceIn(
        RuleEngine.MIN_WORK_DURATION_MINUTES,
        RuleEngine.MAX_WORK_DURATION_MINUTES
    )
    val restMinutes = RuleEngine.calculateRecommendedBreakSeconds(plannedMinutes) / 60
    val presets = listOf(50, 65, 80)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = StudyFlowColors.CanvasTop,
        contentColor = StudyFlowColors.InkPrimary,
        scrimColor = StudyFlowColors.InkPrimary.copy(alpha = 0.24f),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        dragHandle = { CompactSheetDragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Новый блок",
                style = MaterialTheme.typography.headlineSmall,
                color = StudyFlowColors.InkPrimary
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = {
                    Text(
                        text = "Название предмета или темы",
                        style = MaterialTheme.typography.bodyLarge,
                        color = StudyFlowColors.InkSubtle
                    )
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = StudyFlowColors.InkPrimary,
                    unfocusedBorderColor = StudyFlowColors.Hairline,
                    cursorColor = StudyFlowColors.InkPrimary,
                    focusedTextColor = StudyFlowColors.InkPrimary,
                    unfocusedTextColor = StudyFlowColors.InkPrimary
                )
            )

            // 3 тактильных чипа нагрузки
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel("Нагрузка")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CognitiveTier.entries.forEach { tier ->
                        val isSelected = selectedTier == tier
                        val showLock = tier == CognitiveTier.TIER_1 && isHardBlocked

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) StudyFlowColors.InkPrimary else Color.White
                                )
                                .border(
                                    width = 0.75.dp,
                                    color = if (isSelected) {
                                        StudyFlowColors.InkPrimary
                                    } else {
                                        StudyFlowColors.Hairline
                                    },
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    view.performTapHaptic()
                                    selectedTier = tier
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                if (showLock) {
                                    LockGlyph(
                                        color = if (isSelected) Color.White else StudyFlowColors.InkMuted,
                                        size = 11.dp
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(5.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isSelected) Color.White else tier.accentColor()
                                            )
                                    )
                                }
                                Text(
                                    text = tier.cleanLabel(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) Color.White else StudyFlowColors.InkPrimary
                                )
                            }
                        }
                    }
                }

                if (selectedTier == CognitiveTier.TIER_1 && isHardBlocked) {
                    Text(
                        text = "Перейдёт в Практику",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudyFlowColors.LoadPractice
                    )
                }
            }

            // Длительность: пресеты 50 / 65 / 80 + слайдер + подсказка отдыха
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SectionLabel("Длительность")
                    Text(
                        text = "$plannedMinutes мин · Отдых $restMinutes мин",
                        style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                        color = StudyFlowColors.InkSecondary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.forEach { preset ->
                        val isActive = plannedMinutes == preset
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isActive) StudyFlowColors.CanvasMid else Color.White
                                )
                                .border(
                                    width = 0.75.dp,
                                    color = if (isActive) {
                                        StudyFlowColors.InkPrimary
                                    } else {
                                        StudyFlowColors.Hairline
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    view.performTapHaptic()
                                    durationSlider = preset.toFloat()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$preset мин",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFeatureSettings = "tnum"
                                ),
                                color = StudyFlowColors.InkPrimary
                            )
                        }
                    }
                }

                Slider(
                    value = durationSlider,
                    onValueChange = { durationSlider = it },
                    valueRange = RuleEngine.MIN_WORK_DURATION_MINUTES.toFloat()..
                        RuleEngine.MAX_WORK_DURATION_MINUTES.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = StudyFlowColors.InkPrimary,
                        activeTrackColor = StudyFlowColors.InkPrimary,
                        inactiveTrackColor = StudyFlowColors.TrackMuted
                    )
                )
            }

            Button(
                onClick = {
                    view.performTapHaptic()
                    onCreate(title, selectedTier, plannedMinutes)
                },
                enabled = title.trim().isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.InkPrimary,
                    contentColor = Color.White,
                    disabledContainerColor = StudyFlowColors.TrackMuted,
                    disabledContentColor = StudyFlowColors.InkSubtle
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                Text(
                    text = "Создать",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun ScoreTile(
    score: Int,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgBrush = if (selected) {
        Brush.verticalGradient(listOf(StudyFlowColors.InkPrimary, StudyFlowColors.InkPrimary))
    } else {
        Brush.verticalGradient(listOf(StudyFlowColors.SurfaceTop, StudyFlowColors.SurfaceBottom))
    }

    Box(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(brush = bgBrush)
            .border(
                width = 0.75.dp,
                color = if (selected) StudyFlowColors.InkPrimary else StudyFlowColors.Hairline,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = score.toString(),
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Light,
                fontFeatureSettings = "tnum"
            ),
            color = if (selected) Color.White else StudyFlowColors.InkPrimary
        )
    }
}

private fun sanitizeSystemMessage(raw: String): String {
    return raw
        .replace("TIER_1", "«Сложное»", ignoreCase = true)
        .replace("TIER_2", "«Практика»", ignoreCase = true)
        .replace("TIER_3", "«Лёгкое»", ignoreCase = true)
        .replace("Tier 1", "«Сложное»", ignoreCase = true)
        .replace("Tier 2", "«Практика»", ignoreCase = true)
        .replace("Tier 3", "«Лёгкое»", ignoreCase = true)
}

private fun formatHoursMinutes(totalMinutes: Int): String {
    val safe = totalMinutes.coerceAtLeast(0)
    val hours = safe / 60
    val minutes = safe % 60
    return String.format(Locale.US, "%d ч %02d м", hours, minutes)
}

private fun formatCompactRussianDate(dateIso: String): String {
    return runCatching {
        val date = LocalDate.parse(dateIso)
        val months = arrayOf(
            "янв", "фев", "мар", "апр", "май", "июн",
            "июл", "авг", "сен", "окт", "ноя", "дек"
        )
        val days = arrayOf("пн", "вт", "ср", "чт", "пт", "сб", "вс")
        val month = months[(date.monthValue - 1).coerceIn(0, 11)]
        val dayOfWeek = days[(date.dayOfWeek.value - 1).coerceIn(0, 6)]
        "${date.dayOfMonth} $month, $dayOfWeek"
    }.getOrDefault(dateIso)
}
