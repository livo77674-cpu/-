// ПУТЬ: com/studyflow/app/data/local/StudyBlockEntity.kt

package com.studyflow.app.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.studyflow.app.domain.model.BlockStatus
import com.studyflow.app.domain.model.CognitiveTier

/**
 * Сущность отдельного учебного блока на конкретную дату.
 *
 * Индексы по `date` и `(date, tier)` ускоряют выборку дневного плана
 * и агрегацию суммарных минут по когнитивным эшелонам.
 *
 * @property id Уникальный автогенерируемый идентификатор блока.
 * @property date Дата выполнения в формате `YYYY-MM-DD`.
 * @property title Название учебной задачи или темы.
 * @property tier Когнитивный эшелон в виде Int (1 — TIER_1, 2 — TIER_2, 3 — TIER_3).
 * @property plannedMinutes Плановая длительность рабочей фазы (обычно 50–80 мин).
 * @property actualMinutes Фактически отработанные минуты в фазе WORK.
 * @property status Текущий статус блока ([BlockStatus]).
 * @property closureNote Заметка из 3-минутного буфера закрытия (точка остановки).
 * @property energyBefore Уровень энергии до начала блока (1..5), null до старта.
 * @property energyAfter Уровень энергии после блока (1..5), null до POST_CHECKIN.
 * @property distractionCount Счётчик нажатий кнопки «Мысли блуждают» внутри блока.
 */
@Entity(
    tableName = "study_blocks",
    indices = [
        Index(value = ["date"]),
        Index(value = ["date", "tier"])
    ]
)
data class StudyBlockEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "date")
    val date: String,

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "tier")
    val tier: Int,

    @ColumnInfo(name = "planned_minutes")
    val plannedMinutes: Int,

    @ColumnInfo(name = "actual_minutes")
    val actualMinutes: Int = 0,

    @ColumnInfo(name = "status")
    val status: BlockStatus = BlockStatus.PLANNED,

    @ColumnInfo(name = "closure_note")
    val closureNote: String = "",

    @ColumnInfo(name = "energy_before")
    val energyBefore: Int? = null,

    @ColumnInfo(name = "energy_after")
    val energyAfter: Int? = null,

    @ColumnInfo(name = "distraction_count")
    val distractionCount: Int = 0
) {
    /**
     * Преобразует целочисленный код эшелона в доменное перечисление [CognitiveTier].
     */
    fun toCognitiveTier(): CognitiveTier = CognitiveTier.fromLevel(tier)
}
