// ПУТЬ: com/studyflow/app/ui/theme/Theme.kt

package com.studyflow.app.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.studyflow.app.domain.model.CognitiveTier

/**
 * Ахроматическая палитра Linear Zinc Metallic + хирургический Liquid Glass.
 * Нулевой синий оттенок, строгий контраст типографики и максимум 3 смысловых микро-акцента.
 */
object StudyFlowColors {
    // Основной металлический холст (Zinc)
    val CanvasTop = Color(0xFFFAFAFA)
    val CanvasMid = Color(0xFFF4F4F5)
    val CanvasBottom = Color(0xFFECEEEF)

    // Холст фазы работы
    val WorkCanvasTop = Color(0xFFFAFAFA)
    val WorkCanvasBottom = Color(0xFFF1F2F4)

    // Прохладный холст обязательного отдыха
    val BreakCanvasTop = Color(0xFFF2F5F4)
    val BreakCanvasBottom = Color(0xFFE6ECEA)

    // Поверхности контента (MetallicSurface)
    val SurfaceTop = Color(0xFFFFFFFF)
    val SurfaceBottom = Color(0xFFFAFAFB)
    val Hairline = Color(0xFFE4E4E7)
    val ControlRingBorder = Color(0xFFD4D4D8)
    val TrackMuted = Color(0xFFE4E4E7)

    // Типографика
    val InkPrimary = Color(0xFF09090B)
    val InkSecondary = Color(0xFF52525B)
    val InkMuted = Color(0xFF71717A)
    val InkSubtle = Color(0xFFA1A1AA)

    // Смысловые микро-акценты нагрузки (5.dp точка или 2.dp линия)
    val LoadHard = Color(0xFF18181B)
    val LoadPractice = Color(0xFFB45309)
    val LoadLight = Color(0xFF047857)

    // Предупреждения и опасные действия
    val WarningBar = Color(0xFFB45309)
    val CriticalBar = Color(0xFFDC2626)
}

/**
 * Безопасный кросс-версионный тактильный отклик для Android 7–15 (API 24–35).
 */
fun View.performTapHaptic() {
    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
}

/**
 * Единственно допустимые пользовательские метки нагрузки (без технического жаргона).
 */
fun CognitiveTier.cleanLabel(): String = when (this) {
    CognitiveTier.TIER_1 -> "Сложное"
    CognitiveTier.TIER_2 -> "Практика"
    CognitiveTier.TIER_3 -> "Лёгкое"
}

/**
 * Микро-акцент уровня нагрузки (только для 5.dp точек и 2.dp линий).
 */
fun CognitiveTier.accentColor(): Color = when (this) {
    CognitiveTier.TIER_1 -> StudyFlowColors.LoadHard
    CognitiveTier.TIER_2 -> StudyFlowColors.LoadPractice
    CognitiveTier.TIER_3 -> StudyFlowColors.LoadLight
}

/**
 * Холодный ахроматический фон матового цинкового металла с верхним световым бликом.
 */
fun Modifier.zincMetallicCanvas(
    topColor: Color = StudyFlowColors.CanvasTop,
    midColor: Color = StudyFlowColors.CanvasMid,
    bottomColor: Color = StudyFlowColors.CanvasBottom
): Modifier = this.drawBehind {
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(topColor, midColor, bottomColor)
        )
    )
    // Мягкий верхний световой блик
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.85f),
                Color.Transparent
            ),
            center = Offset(size.width * 0.5f, 0f),
            radius = size.width * 0.9f
        )
    )
}

/**
 * Матовая металлическая контентная поверхность (без теней и раздутых углов):
 * микроградиент #FFFFFF -> #FAFAFB, фаска 0.75.dp (белый верх -> #E4E4E7 низ).
 */
@Composable
fun MetallicSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val fillBrush = Brush.verticalGradient(
        colors = listOf(
            StudyFlowColors.SurfaceTop,
            StudyFlowColors.SurfaceBottom
        )
    )
    val bevelBrush = Brush.verticalGradient(
        colors = listOf(
            Color.White,
            StudyFlowColors.Hairline
        )
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(brush = fillBrush, shape = shape)
            .border(width = 0.75.dp, brush = bevelBrush, shape = shape),
        content = content
    )
}

/**
 * Кросс-версионный хирургический Liquid Glass (API 24–35, без Modifier.blur):
 * - Многослойная полупрозрачная заливка
 * - Спекулярный кант 0.85.dp (белый верх-лево -> сталь -> мягкий белый низ)
 * - Внутреннее верхнее отражение 1.dp через drawWithContent
 * Используется ТОЛЬКО для плавающих контролов, капсул и центральной линзы таймера.
 */
@Composable
fun LiquidGlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(50),
    isCircularLens: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val glassFill = Brush.verticalGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.80f),
            Color(0xFFF4F4F5).copy(alpha = 0.56f)
        )
    )
    val specularRim = Brush.linearGradient(
        colors = listOf(
            Color.White,
            Color(0xFFD4D4D8).copy(alpha = 0.55f),
            Color.White.copy(alpha = 0.78f)
        )
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(brush = glassFill, shape = shape)
            .drawWithContent {
                drawContent()
                val strokePx = 1.dp.toPx()
                if (isCircularLens || shape == CircleShape) {
                    // Внутреннее оптическое верхнее отражение на круглой линзе
                    drawArc(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.90f),
                                Color.Transparent
                            ),
                            startY = 0f,
                            endY = size.height * 0.42f
                        ),
                        startAngle = 205f,
                        sweepAngle = 130f,
                        useCenter = false,
                        topLeft = Offset(strokePx * 1.5f, strokePx * 1.5f),
                        size = Size(size.width - strokePx * 3f, size.height - strokePx * 3f),
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )
                } else {
                    // Внутренний верхний блик 1.dp для капсул и плавающих контролов
                    drawLine(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.92f),
                                Color.Transparent
                            )
                        ),
                        start = Offset(size.width * 0.10f, strokePx),
                        end = Offset(size.width * 0.90f, strokePx),
                        strokeWidth = strokePx,
                        cap = StrokeCap.Round
                    )
                }
            }
            .border(width = 0.85.dp, brush = specularRim, shape = shape),
        content = content
    )
}

// ============================================================================
// Единый набор минималистичных 1.5.dp векторных глифов на Compose Canvas
// (нулевой риск Unresolved reference при отсутствии material-icons-extended)
// ============================================================================

@Composable
fun PlayGlyph(
    color: Color = StudyFlowColors.InkPrimary,
    size: Dp = 14.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.28f, h * 0.16f)
            lineTo(w * 0.84f, h * 0.50f)
            lineTo(w * 0.28f, h * 0.84f)
            close()
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 1.5.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
fun PauseGlyph(
    color: Color = Color.White,
    size: Dp = 14.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val stroke = 1.5.dp.toPx()
        val top = this.size.height * 0.18f
        val bottom = this.size.height * 0.82f
        drawLine(
            color = color,
            start = Offset(this.size.width * 0.34f, top),
            end = Offset(this.size.width * 0.34f, bottom),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = color,
            start = Offset(this.size.width * 0.66f, top),
            end = Offset(this.size.width * 0.66f, bottom),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun PlusGlyph(
    color: Color = Color.White,
    size: Dp = 14.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val stroke = 1.5.dp.toPx()
        val cx = this.size.width * 0.5f
        val cy = this.size.height * 0.5f
        val pad = this.size.minDimension * 0.18f
        drawLine(
            color = color,
            start = Offset(pad, cy),
            end = Offset(this.size.width - pad, cy),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = color,
            start = Offset(cx, pad),
            end = Offset(cx, this.size.height - pad),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun MoonGlyph(
    color: Color = StudyFlowColors.InkPrimary,
    size: Dp = 13.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = 1.4.dp.toPx()
        val path = Path().apply {
            arcTo(
                rect = Rect(w * 0.12f, h * 0.12f, w * 0.88f, h * 0.88f),
                startAngleDegrees = 35f,
                sweepAngleDegrees = 250f,
                forceMoveTo = true
            )
            cubicTo(
                w * 0.42f, h * 0.34f,
                w * 0.46f, h * 0.66f,
                w * 0.80f, h * 0.72f
            )
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = stroke,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
fun CheckGlyph(
    color: Color = StudyFlowColors.InkPrimary,
    size: Dp = 14.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.18f, h * 0.54f)
            lineTo(w * 0.40f, h * 0.76f)
            lineTo(w * 0.84f, h * 0.26f)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 1.5.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
fun CloseGlyph(
    color: Color = StudyFlowColors.InkPrimary,
    size: Dp = 14.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val stroke = 1.5.dp.toPx()
        val p = this.size.minDimension * 0.22f
        val end = this.size.minDimension - p
        drawLine(
            color = color,
            start = Offset(p, p),
            end = Offset(end, end),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = color,
            start = Offset(end, p),
            end = Offset(p, end),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun TrashGlyph(
    color: Color = StudyFlowColors.InkSubtle,
    size: Dp = 15.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = 1.4.dp.toPx()

        // Верхняя крышка
        drawLine(
            color = color,
            start = Offset(w * 0.16f, h * 0.28f),
            end = Offset(w * 0.84f, h * 0.28f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        // Ручка крышки
        drawLine(
            color = color,
            start = Offset(w * 0.38f, h * 0.16f),
            end = Offset(w * 0.62f, h * 0.16f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        // Корпус корзины
        val body = Path().apply {
            moveTo(w * 0.25f, h * 0.28f)
            lineTo(w * 0.31f, h * 0.84f)
            lineTo(w * 0.69f, h * 0.84f)
            lineTo(w * 0.75f, h * 0.28f)
        }
        drawPath(
            path = body,
            color = color,
            style = Stroke(
                width = stroke,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
fun LockGlyph(
    color: Color = StudyFlowColors.InkMuted,
    size: Dp = 12.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = 1.4.dp.toPx()

        // Дужка замка
        val shackle = Path().apply {
            moveTo(w * 0.30f, h * 0.46f)
            lineTo(w * 0.30f, h * 0.32f)
            arcTo(
                rect = Rect(w * 0.30f, h * 0.14f, w * 0.70f, h * 0.50f),
                startAngleDegrees = 180f,
                sweepAngleDegrees = 180f,
                forceMoveTo = false
            )
            lineTo(w * 0.70f, h * 0.46f)
        }
        drawPath(
            path = shackle,
            color = color,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )

        // Корпус замка
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.18f, h * 0.46f),
            size = Size(w * 0.64f, h * 0.42f),
            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()),
            style = Stroke(width = stroke)
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private val StudyFlowZincColorScheme = lightColorScheme(
    primary = StudyFlowColors.InkPrimary,
    onPrimary = Color.White,
    primaryContainer = StudyFlowColors.CanvasMid,
    onPrimaryContainer = StudyFlowColors.InkPrimary,
    secondary = StudyFlowColors.InkSecondary,
    onSecondary = Color.White,
    secondaryContainer = StudyFlowColors.TrackMuted,
    onSecondaryContainer = StudyFlowColors.InkPrimary,
    background = StudyFlowColors.CanvasTop,
    onBackground = StudyFlowColors.InkPrimary,
    surface = StudyFlowColors.SurfaceTop,
    onSurface = StudyFlowColors.InkPrimary,
    surfaceVariant = StudyFlowColors.SurfaceBottom,
    onSurfaceVariant = StudyFlowColors.InkSecondary,
    outline = StudyFlowColors.Hairline,
    outlineVariant = StudyFlowColors.Hairline,
    error = StudyFlowColors.CriticalBar,
    onError = Color.White
)

private val StudyFlowTypography = Typography(
    displayLarge = TextStyle(
        fontWeight = FontWeight.Light,
        fontSize = 56.sp,
        lineHeight = 62.sp,
        letterSpacing = (-2.2).sp,
        fontFeatureSettings = "tnum"
    ),
    displayMedium = TextStyle(
        fontWeight = FontWeight.Light,
        fontSize = 36.sp,
        lineHeight = 42.sp,
        letterSpacing = (-1.4).sp,
        fontFeatureSettings = "tnum"
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        letterSpacing = (-0.4).sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 17.sp,
        lineHeight = 22.sp,
        letterSpacing = (-0.2).sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = (-0.2).sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 18.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.2.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.2.sp
    )
)

@Composable
fun StudyFlowTheme(
    content: @Composable () -> Unit
) {
    // Принудительно включаем тёмные высококонтрастные иконки статус-бара и навигации
    // поверх светлого металлического холста (перекрывает SystemBarStyle.dark в MainActivity.kt)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = true
            controller.isAppearanceLightNavigationBars = true
        }
    }

    MaterialTheme(
        colorScheme = StudyFlowZincColorScheme,
        typography = StudyFlowTypography,
        content = content
    )
}
